# Availability Status Workflow Design

## Execution model
| Step | Action |
|---|---|
| 1 | Current repo workflow builds or refreshes `data.json` |
| 2 | Availability validator checks `watch_source_availability.json` |
| 3 | Availability enrichment script updates `data.json` |
| 4 | Validation confirms required fields exist and JSON still parses |
| 5 | Pages consume enriched `data.json` |

## Recommended workflow strategy
| Strategy | Decision |
|---|---|
| Independent manual workflow | Yes |
| Chained post-build workflow | Yes |
| Replace current workflow | No |

## Required workflow outputs
| Output | Purpose |
|---|---|
| validation log | prove source file is valid |
| enrichment log | prove counts and decisions |
| JSON parse validation | prove output is not corrupted |
| changed entity counts | prove actual application |
