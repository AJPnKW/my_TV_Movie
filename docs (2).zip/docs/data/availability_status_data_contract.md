# Availability Status Data Contract

## Source file
Recommended path:
`data/watch_source_availability.json`

## Source file structure
```json
{
  "version": "1.0.0",
  "generated_at": "2026-03-21T00:00:00Z",
  "records": [
    {
      "entity_type": "movie",
      "entity_key": "movie:example-movie",
      "status_override": "available",
      "primary_watch_url": "https://example.com/watch/example-movie",
      "requires_url": true,
      "url_test_result": "pass",
      "url_test_http_status": 200,
      "release_date_override": "2024-09-01",
      "reason": "manual or computed source note"
    }
  ]
}
```

## Required source fields
| Field | Required | Notes |
|---|---:|---|
| `entity_type` | Yes | `movie`, `show`, `season`, `episode` |
| `entity_key` | Yes | Stable key |
| `status_override` | No | Optional manual override |
| `primary_watch_url` | No | Canonical primary URL |
| `requires_url` | No | Defaults by logic if needed |
| `url_test_result` | No | `pass`, `fail`, `skip`, `unknown` |
| `reason` | No | Traceability |

## Required target fields in `data.json`
| Field | Required |
|---|---:|
| `availability_status` | Yes |
| `availability_checked_at` | Yes |
| `availability_source` | Yes |
| `availability_reason` | Yes |

## Matching rules Codex must verify against the real repo
| Entity | Preferred matching order |
|---|---|
| Movie | `id` → `slug` → `tmdb_id` |
| Show | `id` → `slug` → `tmdb_id` |
| Season | explicit season id if present, else composite key |
| Episode | explicit episode id if present, else composite key |

## Composite key baseline
| Entity | Baseline composite key |
|---|---|
| Season | `show:{show_id}:season:{season_number}` |
| Episode | `show:{show_id}:season:{season_number}:episode:{episode_number}` |

## Important rule
Codex must verify real current keys in the repo and adjust to that reality instead of assuming this baseline literally.
