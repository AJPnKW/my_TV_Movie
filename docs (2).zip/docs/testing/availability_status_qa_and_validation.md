# Availability Status QA and Validation

## Required validation categories
| Category | Required |
|---|---:|
| Python syntax compile | Yes |
| JSON parse validation | Yes |
| Source file duplicate-key validation | Yes |
| Enum validation | Yes |
| End-to-end enrichment dry run | Yes |
| Post-enrichment field presence validation | Yes |
| UI render validation on real pages | Yes |
| Workflow validation | Yes |

## Test cases
| Case | Expected result |
|---|---|
| Future-dated movie | `not_yet_released` |
| Released movie with passing URL | `available` |
| Released movie with failing URL | `unavailable` |
| Released item with missing required URL | `unavailable` |
| Missing release date and no override | `unknown` |
| Unmatched record | `unknown` |
| Duplicate source keys | validator fail |
| Invalid enum | validator fail |

## Required QA artifacts Codex must produce
| Artifact | Purpose |
|---|---|
| implementation summary | what changed |
| file inventory | exact files changed |
| validation summary | what passed |
| logs or report files | evidence |
| known gaps | if any remain |
