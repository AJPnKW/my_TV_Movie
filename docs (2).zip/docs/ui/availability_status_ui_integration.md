# Availability Status UI Integration

## Outcome
Every applicable movie/show/season/episode display surface should be able to render one normalized availability indicator based on `availability_status`.

## Target surfaces
| Surface | Required |
|---|---:|
| index/list pages | Yes |
| show cards | Yes |
| movie cards | Yes |
| season displays if present | Yes |
| episode rows | Yes |
| popups/details | Yes |

## Rendering rule
Pages must read `availability_status` from `data.json` and render one shared status badge/icon pattern.

## Shared mapping
| `availability_status` | UI label |
|---|---|
| `available` | Available |
| `unavailable` | Unavailable |
| `not_yet_released` | Not Yet Released |
| `unknown` | Unknown |

## UI implementation rule
Codex must inspect the current component/helper/page architecture and integrate into the existing rendering pattern instead of inventing a parallel UI system.
