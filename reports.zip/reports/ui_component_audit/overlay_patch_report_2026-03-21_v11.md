# Overlay patch 2026-03-21 v11

## Included
- web/index.html
- web/shows.html
- web/movies.html
- web/calendar.html
- web/discover.html
- web/config.html
- web/library_editor.html
- web/watch_me/watch_me.html
- web/js/action_bar.js
- web/js/app_runtime.js
- web/inputs_editor.html
- tools/start_inputs_editor.ps1
- tools/start_inputs_editor.cmd

## Purpose
- make all shell nav links point Inputs Editor directly to the usable local editor server
- convert the in-app Inputs Editor panel to a compact launcher surface instead of a giant fake embedded editor
- align watch_me with the same top-nav shell language
- enforce a clearer left/center/right action strip structure
- auto-close the watch-source popup after source selection

## Notes
- This patch is focused on shell/editor/popup/action-strip behavior.
- It does not include a full asset workflow repair or full card-size redesign.
