# Overlay patch 2026-03-21 v13

ChromeTV-first / D-pad-first stabilization pass.
