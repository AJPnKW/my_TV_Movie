Asset workflow patch applied
