# Overlay patch 2026-03-21 v12

## Purpose
Repair the show popup season/episode structure so it aligns more closely with the Heated Rivalry reference.

## Included
- `web/js/app_runtime.js`
- `web/css/main_app.css`

## What changed
- replaced the show popup season section from card-carousel style to:
  - left season selector list
  - right season detail panel
- replaced the episode section from a simple grid to a horizontal episode carousel
- kept episode actions on each card while moving the structure closer to the intended reference layout
- added denser popup chips/detail styling and popup-specific episode card styling

## Notes
This patch focuses only on the show popup season + episodes formatting issue raised in the latest screenshots.
