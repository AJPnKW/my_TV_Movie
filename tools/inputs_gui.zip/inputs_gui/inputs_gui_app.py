# ==============================================================================
# [FILE]    inputs_gui_app.py
# [PROJECT] my_TV_Movie
# [ROLE]    PySide6 GUI to manage data/inputs.json (TMDB search + list management)
# [VERSION] v0.2.0
# [UPDATED] 2026-02-24
#
# [CHANGELOG]
# - v0.2.0: 2-column layout (Search | Library), selection column + bulk actions,
#           sort/filter, status+poster, save/reload confirmations, detail panel enriched
# - v0.1.0: initial GUI
# ==============================================================================
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests
from PySide6 import QtCore, QtGui, QtWidgets

from .inputs_gui_model import InputsItem, InputsModel


APP_TITLE = "my_TV_Movie • Inputs Editor (GUI)"
APP_VERSION = "v0.2.0"

TMDB_BASE = "https://api.themoviedb.org/3"


def tmdb_search(api_key: str, kind: str, query: str) -> List[Dict[str, Any]]:
    url = f"{TMDB_BASE}/search/{kind}"
    params = {"api_key": api_key, "query": query, "include_adult": "false"}
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    data = r.json() or {}
    out: List[Dict[str, Any]] = []
    for x in data.get("results", []) or []:
        title = x.get("name") if kind == "tv" else x.get("title")
        date = x.get("first_air_date") if kind == "tv" else x.get("release_date")
        year = str(date)[:4] if date else ""
        out.append(
            {
                "kind": kind,
                "tmdb_id": int(x.get("id")),
                "title": str(title or "").strip(),
                "year": year,
                "date": str(date or ""),
                "popularity": float(x.get("popularity") or 0.0),
            }
        )
    return out


class SeasonsDialog(QtWidgets.QDialog):
    def __init__(self, parent: QtWidgets.QWidget, item: InputsItem) -> None:
        super().__init__(parent)
        self.setWindowTitle("Edit Seasons")
        self.setModal(True)
        self._item = item

        self.mode = QtWidgets.QComboBox()
        self.mode.addItems(["ALL", "List (e.g., 1,2,3)", "Start+ (e.g., 3+ future)"])

        self.list_edit = QtWidgets.QLineEdit()
        self.list_edit.setPlaceholderText("1,2,3")

        self.start_spin = QtWidgets.QSpinBox()
        self.start_spin.setRange(1, 1000)
        self.start_spin.setValue(1)

        self.future_chk = QtWidgets.QCheckBox("Include future seasons")
        self.future_chk.setChecked(True)

        form = QtWidgets.QFormLayout()
        form.addRow("Mode:", self.mode)
        form.addRow("Seasons list:", self.list_edit)

        h = QtWidgets.QHBoxLayout()
        h.addWidget(self.start_spin)
        h.addWidget(self.future_chk)
        form.addRow("Start+:", h)

        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)

        layout = QtWidgets.QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(btns)

        s = item.seasons
        if s in ("all", "*", None):
            self.mode.setCurrentIndex(0)
        elif isinstance(s, list):
            self.mode.setCurrentIndex(1)
            self.list_edit.setText(",".join(str(int(x)) for x in s))
        elif isinstance(s, dict):
            self.mode.setCurrentIndex(2)
            self.start_spin.setValue(int(s.get("start") or s.get("nplus") or 1))
            self.future_chk.setChecked(bool(s.get("future", True)))
        else:
            self.mode.setCurrentIndex(0)

        self._mode_changed()
        self.mode.currentIndexChanged.connect(self._mode_changed)

    def _mode_changed(self) -> None:
        idx = self.mode.currentIndex()
        self.list_edit.setEnabled(idx == 1)
        self.start_spin.setEnabled(idx == 2)
        self.future_chk.setEnabled(idx == 2)

    def result_value(self) -> Any:
        idx = self.mode.currentIndex()
        if idx == 0:
            return None
        if idx == 1:
            raw = self.list_edit.text().strip()
            if not raw:
                return []
            parts = [p.strip() for p in raw.split(",") if p.strip()]
            return [int(p) for p in parts]
        return {"start": int(self.start_spin.value()), "future": bool(self.future_chk.isChecked())}


class MainWindow(QtWidgets.QMainWindow):
    COL_SELECT = 0
    COL_IN_SCOPE = 1
    COL_KIND = 2
    COL_POSTER = 3
    COL_TITLE = 4
    COL_TMDB_ID = 5
    COL_STATUS = 6
    COL_SEASONS = 7

    HEADERS = ["", "In scope", "Type", "Poster", "Title", "TMDB ID", "Status", "Seasons"]

    def __init__(self, repo_root: Path, inputs_path: Path, tmdb_key: str) -> None:
        super().__init__()
        self.repo_root = repo_root
        self.inputs_path = inputs_path
        self.tmdb_key = tmdb_key

        self.model = InputsModel(repo_root=repo_root, inputs_path=inputs_path)
        self.model.load_inputs()

        self._dirty = False
        self._search_results: List[Dict[str, Any]] = []
        self._row_to_item: List[InputsItem] = []

        self.setWindowTitle(f"{APP_TITLE} • {APP_VERSION}")
        self.resize(1300, 760)

        root = QtWidgets.QWidget()
        self.setCentralWidget(root)
        grid = QtWidgets.QGridLayout(root)
        grid.setContentsMargins(12, 12, 12, 12)
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(12)

        left = self._build_search_panel()
        right = self._build_library_panel()

        grid.addWidget(left, 0, 0)
        grid.addWidget(right, 0, 1)
        grid.setColumnStretch(0, 4)
        grid.setColumnStretch(1, 9)

        self._refresh_library_table()

    def _build_search_panel(self) -> QtWidgets.QWidget:
        box = QtWidgets.QGroupBox("Find on TMDB")
        v = QtWidgets.QVBoxLayout(box)

        top = QtWidgets.QHBoxLayout()
        self.search_text = QtWidgets.QLineEdit()
        self.search_text.setPlaceholderText("Search TMDB… (title)")
        self.search_kind = QtWidgets.QComboBox()
        self.search_kind.addItems(["TV", "Movie"])
        self.search_btn = QtWidgets.QPushButton("Search")
        self.search_btn.clicked.connect(self._do_search)
        self.search_text.returnPressed.connect(self._do_search)

        top.addWidget(self.search_text, 1)
        top.addWidget(self.search_kind)
        top.addWidget(self.search_btn)
        v.addLayout(top)

        sortrow = QtWidgets.QHBoxLayout()
        self.search_sort = QtWidgets.QComboBox()
        self.search_sort.addItems(["A→Z", "Z→A", "Year (new→old)", "Year (old→new)", "Popularity (high→low)"])
        self.search_sort.currentIndexChanged.connect(self._render_search_results)
        sortrow.addWidget(QtWidgets.QLabel("Sort:"))
        sortrow.addWidget(self.search_sort)
        sortrow.addStretch(1)
        v.addLayout(sortrow)

        self.search_list = QtWidgets.QListWidget()
        self.search_list.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.search_list.currentRowChanged.connect(self._search_selection_changed)
        v.addWidget(self.search_list, 1)

        self.search_detail = QtWidgets.QGroupBox("Selected")
        dv = QtWidgets.QVBoxLayout(self.search_detail)
        self.search_detail_title = QtWidgets.QLabel("—")
        self.search_detail_title.setWordWrap(True)
        self.search_detail_meta = QtWidgets.QLabel("")
        self.search_detail_meta.setWordWrap(True)
        self.search_detail_poster = QtWidgets.QLabel("")
        self.search_detail_poster.setFixedHeight(180)
        self.search_detail_poster.setAlignment(QtCore.Qt.AlignCenter)
        self.search_detail_poster.setStyleSheet("border:1px solid #333; border-radius:6px;")
        dv.addWidget(self.search_detail_title)
        dv.addWidget(self.search_detail_meta)
        dv.addWidget(self.search_detail_poster)
        v.addWidget(self.search_detail)

        self.add_btn = QtWidgets.QPushButton("Add selected →")
        self.add_btn.clicked.connect(self._add_selected_search_result)
        self.add_btn.setEnabled(False)
        v.addWidget(self.add_btn)

        return box

    def _build_library_panel(self) -> QtWidgets.QWidget:
        box = QtWidgets.QGroupBox("My List (data/inputs.json)")
        v = QtWidgets.QVBoxLayout(box)

        header = QtWidgets.QHBoxLayout()
        self.count_lbl = QtWidgets.QLabel("")
        self.filter_text = QtWidgets.QLineEdit()
        self.filter_text.setPlaceholderText("Filter library…")
        self.filter_text.textChanged.connect(self._refresh_library_table)

        self.select_all_chk = QtWidgets.QCheckBox("Select all")
        self.select_all_chk.stateChanged.connect(self._select_all_rows)

        self.reload_btn = QtWidgets.QPushButton("Reload")
        self.reload_btn.clicked.connect(self._reload_inputs)
        self.save_btn = QtWidgets.QPushButton("Save")
        self.save_btn.clicked.connect(self._save_inputs)

        header.addWidget(self.count_lbl)
        header.addStretch(1)
        header.addWidget(self.filter_text, 2)
        header.addWidget(self.select_all_chk)
        header.addWidget(self.reload_btn)
        header.addWidget(self.save_btn)
        v.addLayout(header)

        self.table = QtWidgets.QTableWidget()
        self.table.setColumnCount(len(self.HEADERS))
        self.table.setHorizontalHeaderLabels(self.HEADERS)
        self.table.setSortingEnabled(True)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.table.itemSelectionChanged.connect(self._library_selection_changed)
        self.table.cellDoubleClicked.connect(self._library_cell_double_clicked)

        hdr = self.table.horizontalHeader()
        hdr.setSectionResizeMode(self.COL_SELECT, QtWidgets.QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(self.COL_IN_SCOPE, QtWidgets.QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(self.COL_KIND, QtWidgets.QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(self.COL_POSTER, QtWidgets.QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(self.COL_TITLE, QtWidgets.QHeaderView.Stretch)
        hdr.setSectionResizeMode(self.COL_TMDB_ID, QtWidgets.QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(self.COL_STATUS, QtWidgets.QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(self.COL_SEASONS, QtWidgets.QHeaderView.ResizeToContents)

        v.addWidget(self.table, 1)

        actions = QtWidgets.QHBoxLayout()
        self.btn_toggle_scope = QtWidgets.QPushButton("Toggle in-scope")
        self.btn_toggle_scope.clicked.connect(self._bulk_toggle_scope)

        self.btn_delete = QtWidgets.QPushButton("Delete selected")
        self.btn_delete.clicked.connect(self._bulk_delete)

        self.btn_edit_seasons = QtWidgets.QPushButton("Edit seasons (TV)")
        self.btn_edit_seasons.clicked.connect(self._edit_selected_tv_seasons)

        actions.addWidget(self.btn_toggle_scope)
        actions.addWidget(self.btn_edit_seasons)
        actions.addWidget(self.btn_delete)
        actions.addStretch(1)
        v.addLayout(actions)

        self.detail = QtWidgets.QGroupBox("Details")
        dv = QtWidgets.QHBoxLayout(self.detail)

        self.detail_poster = QtWidgets.QLabel("")
        self.detail_poster.setFixedSize(120, 180)
        self.detail_poster.setAlignment(QtCore.Qt.AlignCenter)
        self.detail_poster.setStyleSheet("border:1px solid #333; border-radius:6px;")

        self.detail_text = QtWidgets.QTextEdit()
        self.detail_text.setReadOnly(True)

        dv.addWidget(self.detail_poster)
        dv.addWidget(self.detail_text, 1)
        v.addWidget(self.detail)

        self.path_lbl = QtWidgets.QLabel(f"Loaded: {str(self.inputs_path)}")
        v.addWidget(self.path_lbl)

        return box

    def _do_search(self) -> None:
        q = self.search_text.text().strip()
        if not q:
            return
        kind = "tv" if self.search_kind.currentText() == "TV" else "movie"
        try:
            self._search_results = tmdb_search(self.tmdb_key, kind, q)
        except Exception as ex:
            QtWidgets.QMessageBox.critical(self, "TMDB search failed", str(ex))
            self._search_results = []
        self._render_search_results()

    def _render_search_results(self) -> None:
        items = list(self._search_results)
        mode = self.search_sort.currentText()
        if mode == "A→Z":
            items.sort(key=lambda x: (x["title"].lower(), x["tmdb_id"]))
        elif mode == "Z→A":
            items.sort(key=lambda x: (x["title"].lower(), x["tmdb_id"]), reverse=True)
        elif mode == "Year (new→old)":
            items.sort(key=lambda x: (x.get("year") or "0000", x["title"].lower()), reverse=True)
        elif mode == "Year (old→new)":
            items.sort(key=lambda x: (x.get("year") or "9999", x["title"].lower()))
        else:
            items.sort(key=lambda x: (x.get("popularity") or 0.0, x["title"].lower()), reverse=True)

        self.search_list.clear()
        for r in items:
            year = f" ({r['year']})" if r.get("year") else ""
            self.search_list.addItem(f"{r['title']}{year}  •  id={r['tmdb_id']}")
        self.search_list.setCurrentRow(0 if self.search_list.count() else -1)
        self._search_results = items

    def _search_selection_changed(self, row: int) -> None:
        self.add_btn.setEnabled(row >= 0 and row < len(self._search_results))
        if row < 0 or row >= len(self._search_results):
            self.search_detail_title.setText("—")
            self.search_detail_meta.setText("")
            self.search_detail_poster.setPixmap(QtGui.QPixmap())
            return
        r = self._search_results[row]
        self.search_detail_title.setText(r["title"])
        self.search_detail_meta.setText(f"Type: {r['kind']}\nYear: {r.get('year','')}\nTMDB ID: {r['tmdb_id']}")
        pix = self._load_local_poster_pixmap(r["kind"], r["tmdb_id"], max_w=220, max_h=180)
        self.search_detail_poster.setPixmap(pix if pix else QtGui.QPixmap())

    def _add_selected_search_result(self) -> None:
        row = self.search_list.currentRow()
        if row < 0 or row >= len(self._search_results):
            return
        r = self._search_results[row]
        if self._has_item(r["kind"], r["tmdb_id"]):
            QtWidgets.QMessageBox.information(self, "Already exists", "That item is already in your inputs.json list.")
            return

        it = InputsItem(kind=r["kind"], tmdb_id=int(r["tmdb_id"]), title=str(r["title"]), in_scope=True)
        if it.kind == "tv":
            it.seasons = None
        self.model.items.append(it)
        self.model.items.sort(key=lambda x: (x.kind, x.title.lower(), x.tmdb_id))
        self.model.refresh_enrichment()
        self._set_dirty(True)
        self._refresh_library_table()
        QtWidgets.QMessageBox.information(self, "Added", f"Added: {it.title} (id={it.tmdb_id})")

    def _has_item(self, kind: str, tmdb_id: int) -> bool:
        return any(it.kind == kind and it.tmdb_id == tmdb_id for it in self.model.items)

    def _refresh_library_table(self) -> None:
        needle = self.filter_text.text().strip().lower()
        visible: List[InputsItem] = []
        for it in self.model.items:
            if not needle or needle in it.title.lower() or needle in str(it.tmdb_id):
                visible.append(it)

        tv_count = sum(1 for it in self.model.items if it.kind == "tv")
        mv_count = sum(1 for it in self.model.items if it.kind == "movie")
        self.count_lbl.setText(f"TV: {tv_count}  •  Movies: {mv_count}  •  Unsaved: {'yes' if self._dirty else 'no'}")

        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(visible))
        self._row_to_item = visible

        for row, it in enumerate(visible):
            sel_item = QtWidgets.QTableWidgetItem("")
            sel_item.setFlags(QtCore.Qt.ItemIsUserCheckable | QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable)
            sel_item.setCheckState(QtCore.Qt.Unchecked)
            self.table.setItem(row, self.COL_SELECT, sel_item)

            scope_item = QtWidgets.QTableWidgetItem("")
            scope_item.setFlags(QtCore.Qt.ItemIsUserCheckable | QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable)
            scope_item.setCheckState(QtCore.Qt.Checked if it.in_scope else QtCore.Qt.Unchecked)
            self.table.setItem(row, self.COL_IN_SCOPE, scope_item)

            kind_item = QtWidgets.QTableWidgetItem("TV" if it.kind == "tv" else "MOVIE")
            kind_item.setFlags(QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable)
            self.table.setItem(row, self.COL_KIND, kind_item)

            poster_item = QtWidgets.QTableWidgetItem("")
            poster_item.setFlags(QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable)
            pix = self._load_local_poster_pixmap(it.kind, it.tmdb_id, max_w=44, max_h=66)
            if pix:
                poster_item.setIcon(QtGui.QIcon(pix))
            self.table.setItem(row, self.COL_POSTER, poster_item)

            title_item = QtWidgets.QTableWidgetItem(it.title)
            title_item.setFlags(QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable)
            self.table.setItem(row, self.COL_TITLE, title_item)

            id_item = QtWidgets.QTableWidgetItem(str(it.tmdb_id))
            id_item.setFlags(QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable)
            self.table.setItem(row, self.COL_TMDB_ID, id_item)

            status_item = QtWidgets.QTableWidgetItem(str(it.status or ""))
            status_item.setFlags(QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable)
            self.table.setItem(row, self.COL_STATUS, status_item)

            seasons_item = QtWidgets.QTableWidgetItem(it.seasons_display())
            seasons_item.setFlags(QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable)
            self.table.setItem(row, self.COL_SEASONS, seasons_item)

        self.table.resizeRowsToContents()
        self.table.setSortingEnabled(True)
        self._sync_select_all_state()

    def _select_all_rows(self, state: int) -> None:
        check = QtCore.Qt.Checked if state == QtCore.Qt.Checked else QtCore.Qt.Unchecked
        self.table.blockSignals(True)
        for r in range(self.table.rowCount()):
            it = self.table.item(r, self.COL_SELECT)
            if it:
                it.setCheckState(check)
        self.table.blockSignals(False)

    def _get_selected_row_indexes(self) -> List[int]:
        out: List[int] = []
        for r in range(self.table.rowCount()):
            it = self.table.item(r, self.COL_SELECT)
            if it and it.checkState() == QtCore.Qt.Checked:
                out.append(r)
        return out

    def _bulk_delete(self) -> None:
        rows = self._get_selected_row_indexes()
        if not rows:
            QtWidgets.QMessageBox.information(self, "Delete selected", "No rows selected.")
            return
        if QtWidgets.QMessageBox.question(self, "Confirm delete", f"Delete {len(rows)} selected item(s)?") != QtWidgets.QMessageBox.Yes:
            return

        to_remove = {id(self._row_to_item[r]) for r in rows if r < len(self._row_to_item)}
        self.model.items = [it for it in self.model.items if id(it) not in to_remove]
        self.model.items.sort(key=lambda x: (x.kind, x.title.lower(), x.tmdb_id))
        self._set_dirty(True)
        self._refresh_library_table()
        QtWidgets.QMessageBox.information(self, "Deleted", f"Deleted {len(rows)} item(s).")

    def _bulk_toggle_scope(self) -> None:
        rows = self._get_selected_row_indexes()
        if not rows:
            QtWidgets.QMessageBox.information(self, "Toggle in-scope", "No rows selected.")
            return
        for r in rows:
            if r < len(self._row_to_item):
                it = self._row_to_item[r]
                it.in_scope = not it.in_scope
        self._set_dirty(True)
        self._refresh_library_table()

    def _edit_selected_tv_seasons(self) -> None:
        rows = self._get_selected_row_indexes()
        if len(rows) != 1:
            QtWidgets.QMessageBox.information(self, "Edit seasons", "Select exactly one TV row.")
            return
        it = self._row_to_item[rows[0]]
        if it.kind != "tv":
            QtWidgets.QMessageBox.information(self, "Edit seasons", "That item is not TV.")
            return
        dlg = SeasonsDialog(self, it)
        if dlg.exec() == QtWidgets.QDialog.Accepted:
            it.seasons = dlg.result_value()
            self._set_dirty(True)
            self._refresh_library_table()

    def _library_selection_changed(self) -> None:
        r = self.table.currentRow()
        if r < 0 or r >= len(self._row_to_item):
            self.detail_text.setPlainText("")
            self.detail_poster.setPixmap(QtGui.QPixmap())
            return
        self._render_detail(self._row_to_item[r])

    def _library_cell_double_clicked(self, row: int, col: int) -> None:
        if row < 0 or row >= len(self._row_to_item):
            return
        it = self._row_to_item[row]
        if col == self.COL_IN_SCOPE:
            it.in_scope = not it.in_scope
            self._set_dirty(True)
            self._refresh_library_table()
            return
        if col == self.COL_SEASONS and it.kind == "tv":
            self._clear_row_selections()
            self.table.item(row, self.COL_SELECT).setCheckState(QtCore.Qt.Checked)
            self._edit_selected_tv_seasons()

    def _clear_row_selections(self) -> None:
        self.table.blockSignals(True)
        for r in range(self.table.rowCount()):
            it = self.table.item(r, self.COL_SELECT)
            if it:
                it.setCheckState(QtCore.Qt.Unchecked)
        self.table.blockSignals(False)

    def _reload_inputs(self) -> None:
        if self._dirty:
            if QtWidgets.QMessageBox.question(self, "Reload", "Discard unsaved changes and reload inputs.json?") != QtWidgets.QMessageBox.Yes:
                return
        self.model.load_inputs()
        self._set_dirty(False)
        self._refresh_library_table()
        QtWidgets.QMessageBox.information(self, "Reloaded", "Reloaded inputs.json from disk.")

    def _save_inputs(self) -> None:
        self._sync_table_to_model()
        try:
            self.model.save_inputs()
        except Exception as ex:
            QtWidgets.QMessageBox.critical(self, "Save failed", str(ex))
            return
        self._set_dirty(False)
        self._refresh_library_table()
        QtWidgets.QMessageBox.information(self, "Saved", "Saved inputs.json to disk.")

    def _sync_table_to_model(self) -> None:
        for r, it in enumerate(self._row_to_item):
            cell = self.table.item(r, self.COL_IN_SCOPE)
            if cell:
                it.in_scope = (cell.checkState() == QtCore.Qt.Checked)

    def _render_detail(self, it: InputsItem) -> None:
        lines = [
            f"Title: {it.title}",
            f"Type: {it.kind}",
            f"TMDB ID: {it.tmdb_id}",
            f"In scope: {'yes' if it.in_scope else 'no'}",
            f"Status: {it.status or ''}",
            f"Seasons: {it.seasons_display()}",
        ]
        self.detail_text.setPlainText("\n".join(lines))
        pix = self._load_local_poster_pixmap(it.kind, it.tmdb_id, max_w=120, max_h=180)
        self.detail_poster.setPixmap(pix if pix else QtGui.QPixmap())

    def _set_dirty(self, dirty: bool) -> None:
        self._dirty = dirty

    def _sync_select_all_state(self) -> None:
        total = self.table.rowCount()
        if total == 0:
            self.select_all_chk.blockSignals(True)
            self.select_all_chk.setChecked(False)
            self.select_all_chk.blockSignals(False)
            return
        selected = len(self._get_selected_row_indexes())
        self.select_all_chk.blockSignals(True)
        self.select_all_chk.setChecked(selected == total)
        self.select_all_chk.blockSignals(False)

    def _load_local_poster_pixmap(self, kind: str, tmdb_id: int, max_w: int, max_h: int) -> Optional[QtGui.QPixmap]:
        path = None
        for it in self.model.items:
            if it.kind == kind and it.tmdb_id == tmdb_id and it.poster_path:
                path = it.poster_path
                break
        if not path:
            return None
        p = Path(path)
        if not p.exists():
            return None
        pix = QtGui.QPixmap(str(p))
        if pix.isNull():
            return None
        return pix.scaled(max_w, max_h, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)


def find_repo_root(start: Path) -> Path:
    cur = start.resolve()
    for _ in range(10):
        if (cur / ".git").exists() or (cur / "scripts").exists():
            return cur
        if cur.parent == cur:
            break
        cur = cur.parent
    return start.resolve()


def main() -> int:
    app = QtWidgets.QApplication(sys.argv)
    repo_root = find_repo_root(Path.cwd())
    inputs_path = repo_root / "data" / "inputs.json"
    tmdb_key = os.environ.get("API_TMDB_KEY", "").strip()
    if not tmdb_key:
        QtWidgets.QMessageBox.critical(None, "Missing TMDB key", "Set env var API_TMDB_KEY before running.")
        return 2
    if not inputs_path.exists():
        QtWidgets.QMessageBox.critical(None, "Missing inputs.json", f"Not found: {str(inputs_path)}")
        return 2
    w = MainWindow(repo_root=repo_root, inputs_path=inputs_path, tmdb_key=tmdb_key)
    w.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
