# ==============================================================================
# [FILE]    inputs_gui_model.py
# [PROJECT] my_TV_Movie
# [ROLE]    inputs.json load/save + validation (GUI model)
# [VERSION] v0.2.0
# [UPDATED] 2026-02-24
#
# [CHANGELOG]
# - v0.2.0: add stable display helpers (status/poster/seasons), optional data.json enrichment
# - v0.1.0: initial GUI model
# ==============================================================================
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class InputsItem:
    kind: str                 # "tv" | "movie"
    tmdb_id: int
    title: str
    in_scope: bool = True
    seasons: Any = None       # tv only: "all" | [] | [1,2] | {"start":N,"future":bool}
    status: Optional[str] = None
    poster_path: Optional[str] = None

    def seasons_display(self) -> str:
        if self.kind != "tv":
            return "--"
        s = self.seasons
        if s in ("all", "*", None):
            return "ALL"
        if isinstance(s, dict):
            start = int(s.get("start") or s.get("nplus") or 1)
            fut = bool(s.get("future", True))
            return f"{start}+ ({'future' if fut else 'no-future'})"
        if isinstance(s, list):
            if len(s) == 0:
                return "—"
            return ",".join(str(int(x)) for x in s)
        return "ALL"


class InputsModel:
    def __init__(self, repo_root: Path, inputs_path: Path) -> None:
        self.repo_root = repo_root
        self.inputs_path = inputs_path
        self.items: List[InputsItem] = []
        self._tmdb_enrichment: Dict[Tuple[str, int], Dict[str, Any]] = {}  # (kind, tmdb_id) -> data
        self._poster_index: Dict[Tuple[str, int], str] = {}

    # ---------------------------
    # load/save inputs.json
    # ---------------------------
    def load_inputs(self) -> None:
        raw = json.loads(self.inputs_path.read_text(encoding="utf-8"))
        self.items = self._decode(raw)
        self.refresh_enrichment()

    def save_inputs(self) -> None:
        obj = self._encode(self.items)
        tmp = self.inputs_path.with_suffix(self.inputs_path.suffix + ".tmp")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.inputs_path)

    # ---------------------------
    # optional enrichment (data.json + local assets)
    # ---------------------------
    def refresh_enrichment(self) -> None:
        self._tmdb_enrichment = self._load_data_json_enrichment()
        self._poster_index = self._build_poster_index()
        for it in self.items:
            meta = self._tmdb_enrichment.get((it.kind, it.tmdb_id), {})
            it.status = meta.get("status") or it.status
            it.poster_path = self._poster_index.get((it.kind, it.tmdb_id)) or it.poster_path

    def _load_data_json_enrichment(self) -> Dict[Tuple[str, int], Dict[str, Any]]:
        data_path = self.repo_root / "data" / "data.json"
        if not data_path.exists():
            return {}
        try:
            d = json.loads(data_path.read_text(encoding="utf-8"))
        except Exception:
            return {}
        out: Dict[Tuple[str, int], Dict[str, Any]] = {}

        # data.json uses "shows" for TV
        for s in d.get("shows", []) or []:
            tid = s.get("tmdb_id")
            if isinstance(tid, int):
                out[("tv", tid)] = {"status": s.get("status"), "title": s.get("title")}

        for m in d.get("movies", []) or []:
            tid = m.get("tmdb_id")
            if isinstance(tid, int):
                out[("movie", tid)] = {"status": m.get("status"), "title": m.get("title")}

        return out

    def _build_poster_index(self) -> Dict[Tuple[str, int], str]:
        assets_dir = self.repo_root / "assets"
        if not assets_dir.exists():
            return {}
        exts = {".jpg", ".jpeg", ".png", ".webp"}
        idx: Dict[Tuple[str, int], str] = {}
        try:
            for p in assets_dir.rglob("*"):
                if not p.is_file():
                    continue
                if p.suffix.lower() not in exts:
                    continue
                stem = p.stem
                if not stem.isdigit():
                    continue
                tid = int(stem)
                kind = "tv" if "tv" in str(p).lower() else ("movie" if "movie" in str(p).lower() else "tv")
                key = (kind, tid)
                if key not in idx:
                    idx[key] = str(p)
        except Exception:
            return {}
        return idx

    # ---------------------------
    # normalize JSON schema
    # ---------------------------
    @staticmethod
    def _decode(obj: Dict[str, Any]) -> List[InputsItem]:
        tv: List[InputsItem] = []
        movies: List[InputsItem] = []

        for x in obj.get("tv", []) or []:
            tv.append(
                InputsItem(
                    kind="tv",
                    tmdb_id=int(x.get("tmdb_id")),
                    title=str(x.get("title") or ""),
                    in_scope=bool(x.get("in_scope", True)),
                    seasons=x.get("seasons"),
                )
            )

        for x in obj.get("movies", []) or []:
            movies.append(
                InputsItem(
                    kind="movie",
                    tmdb_id=int(x.get("tmdb_id")),
                    title=str(x.get("title") or ""),
                    in_scope=bool(x.get("in_scope", True)),
                )
            )

        items = tv + movies
        items.sort(key=lambda it: (it.kind, it.title.lower(), it.tmdb_id))
        return items

    @staticmethod
    def _encode(items: List[InputsItem]) -> Dict[str, Any]:
        tv_list: List[Dict[str, Any]] = []
        mv_list: List[Dict[str, Any]] = []

        for it in items:
            if it.kind == "tv":
                row: Dict[str, Any] = {
                    "tmdb_id": int(it.tmdb_id),
                    "title": it.title,
                    "in_scope": bool(it.in_scope),
                }
                if it.seasons is not None:
                    row["seasons"] = it.seasons
                tv_list.append(row)
            else:
                mv_list.append(
                    {
                        "tmdb_id": int(it.tmdb_id),
                        "title": it.title,
                        "in_scope": bool(it.in_scope),
                    }
                )

        tv_list.sort(key=lambda x: (str(x.get("title") or "").lower(), int(x.get("tmdb_id") or 0)))
        mv_list.sort(key=lambda x: (str(x.get("title") or "").lower(), int(x.get("tmdb_id") or 0)))
        return {"tv": tv_list, "movies": mv_list}
