# Architecture Change Log

Purpose: Maintain a deterministic history of architectural decisions and
structural corrections in the **my_TV_Movie** repository.

Only record **architecture-level changes**, not minor UI tweaks.

------------------------------------------------------------------------

## 2026-03-16 --- UI Stabilization Baseline

### Context

Initial architecture documentation and stabilization process introduced
to correct UI drift and enforce a consistent rendering model.

### Key Architectural Decisions

#### 1. Single Data Source Model

-   `data/inputs.json` is the canonical user-maintained input file.
-   `data/data.json` is the generated runtime dataset.
-   All UI pages must read from `data/data.json`.

#### 2. Canonical Editor

-   `web/inputs_editor.html` is the only supported editor.
-   `web/library_editor.html` remains retired / redirect-only.

#### 3. Shared Rendering System

Renderer

    web/js/card_renderer.js

Actions

    web/js/action_bar.js

Runtime

    web/js/app_runtime.js

#### 4. Card Rendering Contract

Every media card must follow the overlay structure:

Poster\
Overlay gradient\
Title\
Metadata\
Icon strip

#### 5. Icon Strip Canonical Order

Movies / Episodes

    🍿  ⌚  💕  🔖  ⭐

Shows / Seasons

    ⌚  💕  🔖  ⭐

#### 6. Page Shell Ownership

Dashboard

    web/index.html

Shows

    web/shows.html

Movies

    web/movies.html

Calendar

    web/calendar.html

Watch Me

    web/watch_me/watch_me.html

#### 7. Calendar Layout Contract

Calendar must be a **full‑width wall calendar**.

Requirements:

-   No left sidebar
-   7‑column grid layout
-   Weekday header row
-   Compact episode cards inside day cells

#### 8. Sidebar Usage

Sidebar allowed on: - Shows - Movies

Sidebar NOT allowed on: - Calendar - Dashboard

------------------------------------------------------------------------

## Future Entries

Each entry must contain:

Date\
Change summary\
Files affected\
Commit hash

Example:

## 2026-03-20 --- Card Renderer Normalization

Summary\
Removed legacy icon button system and enforced canonical icon strip.

Files

    web/js/card_renderer.js
    web/js/action_bar.js

Commit

    abc1234
